// Demo data (replace with your real-time data / socket integration)
const contacts = [
  { uid:'u_aryan', name:'Aryan Choudhary', avatar:'Screenshot 2025-09-05 133836.png', last:'Hey -- are you coming?', unread:2, online:true },
  { uid:'u_rajput', name:'Sovik Rajput', avatar:'Screenshot 2025-09-05 133659.png', last:'Sent a file', unread:0, online:false },
  { uid:'u_cara', name:'Cara Singh', avatar:'Screenshot 2025-09-05 133659.png', last:'Let\'s meet', unread:5, online:true }
];

const contactsList = document.getElementById('contactsList');
const chatMain = document.getElementById('chatMain');
const chatName = document.getElementById('chatName');
const chatSub = document.getElementById('chatSub');
const chatAvatar = document.getElementById('chatAvatar');
const searchInput = document.getElementById('searchInput');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const attachBtn = document.getElementById('attachBtn');
const fileInput = document.getElementById('fileInput');
const notifSound = document.getElementById('notifSound');
const soundToggle = document.getElementById('soundToggle');
let currentContact = null;

const themeToggle = document.getElementById('darkToggle');
const savedTheme = localStorage.getItem('chat-theme');
if (savedTheme) document.documentElement.setAttribute('data-theme', savedTheme);
themeToggle.addEventListener('click', ()=>{
  const cur = document.documentElement.getAttribute('data-theme');
  const next = cur==='light' ? '' : 'light';
  if(next) document.documentElement.setAttribute('data-theme', next); 
  else document.documentElement.removeAttribute('data-theme');
  localStorage.setItem('chat-theme', next);
});

function renderContacts(list){ 
  contactsList.innerHTML='';
  for(const c of list){ 
    const div = document.createElement('div'); 
    div.className='contact'+(c.unread? ' unread':''); 
    div.dataset.uid=c.uid; 
    div.innerHTML = `
      <img class="avatar" src="${c.avatar}" />
      <div class="meta"><strong>${c.name}</strong><div class="small">${c.last}</div></div>
      ${c.unread? `<div class="badge">${c.unread}</div>` : ''}`;
    div.addEventListener('click', ()=>openChat(c)); 
    contactsList.appendChild(div);
  }
}
renderContacts(contacts);

searchInput.addEventListener('input', ()=>{
  const q=searchInput.value.toLowerCase(); 
  renderContacts(contacts.filter(c=>
    c.name.toLowerCase().includes(q) || c.last.toLowerCase().includes(q)
  )); 
});

function openChat(contact){ 
  currentContact = contact; 
  chatName.textContent = contact.name; 
  chatAvatar.src = contact.avatar; 
  chatSub.textContent = contact.online ? 'Online' : 'Last seen recently';
  chatMain.innerHTML='';
  const demoMessages = [
    { id:1, from:contact.uid, text:'Hi there!', ts:Date.now()-1000*60*60, status:'delivered' },
    { id:2, from:'me', text:'Hello! How are you?', ts:Date.now()-1000*60*50, status:'read' },
    { id:3, from:contact.uid, text:contact.last, ts:Date.now()-1000*60*5, status:'sent' }
  ];
  for(const m of demoMessages) appendMsgBubble(m);
  contact.unread = 0; renderContacts(contacts);
  messageInput.focus();
  scrollToBottom();
}

function appendMsgBubble(m){ 
  const b = document.createElement('div'); 
  b.className='bubble'+(m.from==='me'?' me':''); 
  b.id='msg-'+m.id;
  if(m.text) b.appendChild(document.createTextNode(m.text));
  const meta = document.createElement('div'); 
  meta.className='meta'; 
  const t = new Date(m.ts).toLocaleTimeString(); 
  const status = document.createElement('span'); 
  status.className='small'; 
  status.innerHTML = statusIcon(m.status);
  meta.appendChild(document.createElement('span')).textContent = t; 
  meta.appendChild(status);
  b.appendChild(meta); 
  chatMain.appendChild(b);
}

function statusIcon(s){ 
  if(s==='sent') return '✅'; 
  if(s==='delivered') return '✅✅'; 
  if(s==='read') return '<span style="color:#3b82f6">✅✅</span>'; 
  return ''; 
}

function scrollToBottom(){ chatMain.scrollTop = chatMain.scrollHeight; }

sendBtn.addEventListener('click', ()=>{
  const txt = messageInput.value.trim(); 
  if(!txt || !currentContact) return; 
  const m = { id:Date.now(), from:'me', text:txt, ts:Date.now(), status:'sent' }; 
  appendMsgBubble(m); 
  messageInput.value='';
  markContactLast(currentContact.uid, txt);
  scrollToBottom(); 
  setTimeout(()=>simulateIncoming(currentContact), 1200);
});

attachBtn.addEventListener('click', ()=> fileInput.click());
fileInput.addEventListener('change', ()=>{
  const f=fileInput.files[0]; if(!f) return; 
  if(f.size>5*1024*1024){ alert('Max 5MB'); return; }
  const m = { id:Date.now(), from:'me', text:`[file] ${f.name}`, ts:Date.now(), status:'sent' }; 
  appendMsgBubble(m); 
  messageInput.value=''; 
  markContactLast(currentContact.uid, '[file] '+f.name); 
  scrollToBottom();
});

function markContactLast(uid, lastText){ 
  const c = contacts.find(x=>x.uid===uid); 
  if(c){ c.last = lastText; c.unread = 0; renderContacts(contacts);} 
}

function simulateIncoming(contact){ 
  const txt = 'Auto reply to: '+contact.name; 
  const m = { id:Date.now()+1, from:contact.uid, text:txt, ts:Date.now(), status:'delivered' };
  if(currentContact && currentContact.uid===contact.uid){ 
    appendMsgBubble(m); 
    scrollToBottom(); 
    setTimeout(()=>{
      const el=document.getElementById('msg-'+(m.id-1)); 
      if(el) el.querySelector('.meta .small') && 
        (document.getElementById('msg-'+(m.id-1)).querySelector('.meta .small').innerHTML='✅✅'); 
    }, 1200);
  } else { 
    contact.unread = (contact.unread||0)+1; 
    renderContacts(contacts); 
    showToast(contact.name+' sent a message'); 
    if(soundToggle.checked) notifSound.play(); 
    notifyBrowser(contact.name, txt); 
  }
}

function showToast(text){ 
  const t=document.createElement('div'); 
  t.className='toast'; 
  t.innerHTML = `<strong>New</strong><div>${text}</div>`; 
  document.body.appendChild(t); 
  setTimeout(()=> t.style.opacity=0, 3000); 
  setTimeout(()=> t.remove(), 3500); 
}

function notifyBrowser(title, body){ 
  if(!('Notification' in window)) return; 
  if(Notification.permission==='granted'){ 
    new Notification(title, { body }); 
  } else if(Notification.permission!=='denied'){ 
    Notification.requestPermission().then(p=>{ 
      if(p==='granted') new Notification(title,{body}); 
    }); 
  } 
}

const obs = new MutationObserver((mut)=>{ scrollToBottom(); });
obs.observe(chatMain, { childList:true, subtree:true });

messageInput.addEventListener('keydown', (e)=>{
  if(e.key==='Enter'){ e.preventDefault(); sendBtn.click(); } 
});

document.getElementById('newMsgBtn').addEventListener('click', ()=>{
  const c = contacts[Math.floor(Math.random()*contacts.length)]; 
  simulateIncoming(c); 
});

openChat(contacts[0]);
